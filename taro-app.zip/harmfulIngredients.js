const harmfulIngredients = [
    'Retinoids', 'Retinols', 'Hydroquinon', 'Retin A', 'aluminium chloride', 'phthalates',
    'Amphetamines', 'Benzophenone', 'Octinoxate', 'Paraffin Oil', 'acrylamide',
    'retinyl palmitate', 'Pyridine', 'hydrogenated cotton seed oil', 'Progestins', 'Urea',
    'Polyethylene Glycol', 'Formaldehyde', 'Butylated hydroxyanisole', 'butylated hydroxytoluene',
    'Potassium bromate', 'Propyl gallate', 'Lead', 'Retinol', 'Salicylic acid', 'Botox', 'homosalate', 'octocrylene', 'octinoxate', 'Accutane',
    'Benzoyl peroxide', 'Cocamidopropyl betaine', 'Dimethicone', 'Homosalate', 'Homomenthyl salicylate',
    '3,3,5-trimethyl-cyclohexyl-salicylate', 'Retinal'
];